from app.repositories.vehicle_repository import VehicleRepository
from app.repositories.telemetry_repository import TelemetryRepository
from app.repositories.redis_repository import RedisRepository


class FleetService:
    """
    Coordinates fleet-related business logic.

    The service layer should not know how data is stored.
    It delegates persistence to repositories.
    """

    def __init__(
        self,
        vehicle_repository: VehicleRepository,
        telemetry_repository: TelemetryRepository,
        redis_repository: RedisRepository,
    ):
        self.vehicle_repository = vehicle_repository
        self.telemetry_repository = telemetry_repository
        self.redis_repository = redis_repository